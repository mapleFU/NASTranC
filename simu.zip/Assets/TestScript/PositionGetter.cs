﻿using UnityEngine;
using System.Collections;

public class PositionGetter : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
//		Debug.Log (gameObject.transform.position);
	}

}

