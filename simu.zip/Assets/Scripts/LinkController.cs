﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimuUtils;

class LinkController: BaseChildObject {
	Hashtable distance_table;
}
