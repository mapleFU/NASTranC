﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SimuUtils{
	public class EscalatorController : StairController {
		// 速度加快

	}
}
