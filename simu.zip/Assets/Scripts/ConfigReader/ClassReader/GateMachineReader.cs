﻿using UnityEngine;
using System.Collections;

/*
Gatemachine
0
r
150 60
155 55
Gatemachine
*/

public class GateMachineReader : MonoBehaviour
{
	public string get_class_name () {
		return null;
	}
}

