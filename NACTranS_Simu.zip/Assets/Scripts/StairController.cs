﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SimuUtils {
	public class StairController : BackgroundController {
		// 要前往的和来自的Lift
		// 边缘有一个给定的Lift


	}
}
